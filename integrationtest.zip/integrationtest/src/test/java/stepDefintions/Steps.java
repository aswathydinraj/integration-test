package stepDefintions;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Steps {


    WebDriver driver;

    @Given("^User opens the google url and clicks on sign in$")
    public void user_opens_the_google_url_and_clicks_on_sign_in() throws Throwable {
        System.setProperty("webdriver.chrome.driver","D:\\driver\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("https://accounts.google.com/signin/v2/identifier?hl=no&passive=true&continue=https%3A%2F%2Fwww.google.com%2F&flowName=GlifWebSignIn&flowEntry=ServiceLogin");
       // driver.findElement(By.xpath(".//*[@id='gb_70")).click();
    }

    @When("^User enters (.+) and (.+)$")
    public void user_enters_nayanika_singh_gmail_com_and_powerpuff(String username, String password) throws Throwable {
       //click username text box
        //driver.findElement(By.xpath("//*[@id=\'identifierId\']")).click();

        //enter username
        driver.findElement(By.xpath("//*[@id='identifierId']")).sendKeys(username);

        //next button click
        driver.findElement(By.xpath("//*[@id='identifierNext']/content/span")).click();

        //click password textbox
        //driver.findElement(By.xpath("//*[@id=\"password\"]/div[1]/div/div[1]/input")).click();

        //enter password //*[@id="yDmH0d"]
       // driver.findElement(By.xpath("//*[@id='password']/div[1]/div/div[1]/input")).click();
        //driver.findElement(By.xpath("//*[@id=\'yDmH0d\']")).click();
        //*[@id="password"]/div[1]/div/div[1]/input
        //click next button
        driver.findElement(By.xpath("//*[@id=\'password\']/div[1]/div/div[1]/input")).sendKeys(password);
    }

    @When("^Clicks log in button$")
    public void clicks_log_in_button() throws Throwable {
        //*[@id="identifierNext"]/content/span
        driver.findElement(By.xpath(".//*[@id='identifierNex']/content/span")).click();
    }

    @Then("^Google gets logged in$")
    public void google_gets_logged_in() throws Throwable {
        System.out.println("Login Successfully");
        driver.findElement(By.xpath("//*[@id=\'passwordNext\']/content/span")).click();

        //click on icon
        driver.findElement(By.xpath("//*[@id='gbw']/div/div/div[2]/div[4]/div[1]/a/span")).click();

        //click on logout //*[@id="gb_71"]
        driver.findElement(By.xpath("//*[@id='gb_71']")).click();
        System.out.println("Logout Successfully");
    }

}
